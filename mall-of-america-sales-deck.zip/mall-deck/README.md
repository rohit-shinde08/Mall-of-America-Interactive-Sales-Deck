# Mall of America — Interactive Sales Deck

A world-class, cinematic interactive sales deck for Mall of America — America's largest shopping and entertainment destination.

## Live Preview
Deploy this folder to any static hosting (GitHub Pages, Netlify, Vercel) for a live URL.

## Tech Stack
- **HTML5** — Semantic, structured markup
- **CSS3** — Custom properties, animations, Grid, Flexbox
- **Vanilla JS** — IntersectionObserver, scroll effects, custom cursor, tab logic
- **Google Fonts** — Bebas Neue (display), Cormorant Garamond (luxury serif), DM Sans (body)

## Project Structure
```
mall-deck/
├── index.html          # Main single-page application
├── css/
│   └── style.css       # All styles, variables, animations
├── js/
│   └── main.js         # Interactivity, scroll effects, counters
└── README.md
```

## Features
- **Cinematic hero** with animated title, live stats, and scroll trigger
- **Non-linear navigation** — viewer controls their journey
- **Scroll-reveal animations** on all content sections
- **Animated stat counters** trigger on viewport entry
- **Interactive event tabs** — Concerts, Brand Activations, Corporate, Launches
- **Custom gold cursor** throughout
- **Loading screen** with brand animation
- **Parallax hero** background
- **Brand ticker** with tenant logos
- **Sponsorship tier cards** — Presenting, Signature, Activation
- **Leasing paths** — Luxury, Mid-Tier, Pop-Up, F&B
- **Fully responsive** — desktop, tablet, mobile

## Sections Covered
1. **Hero** — Cinematic intro with key stats
2. **Overview** — Location, demographics, reach
3. **Retail** — Categories, brands, ticker
4. **Luxury** — Elevated positioning, proof points
5. **Dining** — F&B as a destination
6. **Entertainment** — Nickelodeon Universe, SEA LIFE, FlyOver, Crayola
7. **Events** — Concerts, brand activations, corporate, product launches
8. **Sponsorship** — Tier-based partnership packages
9. **Leasing Paths** — Segmented by category
10. **Partner / CTA** — 3 contact pathways

## Design Direction
**Aesthetic:** Luxury-Cinematic Dark / Gold
- Color palette: Deep black (#050505) + Warm gold (#D4AF37) + White (#FAFAF8)
- Typography: Bebas Neue (impact headlines) + Cormorant Garamond (luxury serif italics) + DM Sans (clean body)
- Inspired by: Apple.com minimalism + Louis Vuitton luxury + Disney energy

## AI Tools Used
- **Claude (Anthropic)** — Architecture, code generation, copywriting, UX design
- **Design system** — CSS custom properties for full theme consistency

## Deploy to Netlify (30 seconds)
1. Drag the `mall-deck` folder to [netlify.com/drop](https://app.netlify.com/drop)
2. Get a live URL instantly

## Deploy to GitHub Pages
```bash
git init
git add .
git commit -m "Initial: MOA interactive sales deck"
git branch -M main
git remote add origin https://github.com/yourusername/moa-deck.git
git push -u origin main
# Then enable GitHub Pages in repo Settings → Pages → main branch
```

## Design Decisions
- **No framework dependency** — Ships as pure HTML/CSS/JS for maximum performance and portability
- **CSS custom properties** — Single source of truth for brand colors and typography
- **IntersectionObserver** — Performant scroll animations without library overhead
- **Non-linear UX** — Sticky nav allows jumping to any section; sections are self-contained
- **Gold accent system** — Consistent hierarchy: gold = emphasis, white = primary, gray = secondary

## What I'd Improve With More Time
- Add real video assets (autoplay background videos per section)
- Build a dedicated venue booking modal
- Add a 3D floor plan interactive map of MOA
- Integrate real-time foot traffic API data
- Add micro-animations to the brand ticker on hover
- Build out a full CMS-driven event calendar module
