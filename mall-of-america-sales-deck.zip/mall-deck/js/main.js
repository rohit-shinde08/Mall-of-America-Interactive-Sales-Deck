/* Mall of America — Interactive Sales Deck JS */

// ======== CUSTOM CURSOR ========
document.addEventListener('mousemove', (e) => {
  document.body.style.setProperty('--cx', e.clientX + 'px');
  document.body.style.setProperty('--cy', e.clientY + 'px');
});

// ======== NAV SCROLL BEHAVIOR ========
const nav = document.getElementById('nav');
const navLinks = document.querySelectorAll('.nav-link');

window.addEventListener('scroll', () => {
  if (window.scrollY > 60) {
    nav.classList.add('scrolled');
  } else {
    nav.classList.remove('scrolled');
  }
  updateActiveNav();
});

function updateActiveNav() {
  const sections = document.querySelectorAll('section[id]');
  const scrollY = window.scrollY + 100;
  sections.forEach(sec => {
    const top = sec.offsetTop;
    const height = sec.offsetHeight;
    const id = sec.getAttribute('id');
    if (scrollY >= top && scrollY < top + height) {
      navLinks.forEach(l => l.classList.remove('active'));
      const active = document.querySelector(`.nav-link[data-section="${id}"]`);
      if (active) active.classList.add('active');
    }
  });
}

// ======== SMOOTH SCROLL ========
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ======== SCROLL REVEAL ========
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      setTimeout(() => {
        entry.target.classList.add('visible');
      }, entry.target.dataset.delay || 0);
    }
  });
}, { threshold: 0.1, rootMargin: '-50px' });

// Add reveal classes to elements
const revealSelectors = [
  '.overview-left', '.overview-right',
  '.cat-card', '.dining-feature',
  '.ent-card', '.tier-card', '.lp-card',
  '.ov-stat', '.demo-card', '.lux-card',
  '.contact-card', '.concept-tag',
  '.dining-feature', '.proof-item'
];

revealSelectors.forEach(selector => {
  document.querySelectorAll(selector).forEach((el, i) => {
    el.classList.add('reveal');
    el.dataset.delay = i * 80;
    revealObserver.observe(el);
  });
});

// Section headings
document.querySelectorAll('.section-heading, .section-label, .body-text, .partner-heading, .partner-sub').forEach((el, i) => {
  el.classList.add('reveal');
  revealObserver.observe(el);
});

// ======== EVENT TABS ========
const eventTypes = document.querySelectorAll('.event-type');
const eventDetails = document.querySelectorAll('.event-detail');

eventTypes.forEach(type => {
  type.addEventListener('click', () => {
    const target = type.dataset.type;
    eventTypes.forEach(t => t.classList.remove('active'));
    eventDetails.forEach(d => d.classList.remove('active'));
    type.classList.add('active');
    const detail = document.querySelector(`.event-detail[data-type="${target}"]`);
    if (detail) {
      detail.classList.add('active');
      detail.style.animation = 'none';
      detail.offsetHeight; // reflow
      detail.style.animation = 'fadeInPanel 0.4s ease forwards';
    }
  });
});

// ======== STAT COUNTER ANIMATION ========
function animateCounter(el, target, suffix = '') {
  const start = 0;
  const duration = 1500;
  const startTime = performance.now();
  const isDecimal = target.toString().includes('.');
  
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 4);
    const current = start + (target - start) * eased;
    el.textContent = isDecimal 
      ? current.toFixed(1) + suffix
      : Math.round(current) + suffix;
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}

const statsObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const el = entry.target;
      const text = el.textContent;
      const num = parseFloat(text.replace(/[^0-9.]/g, ''));
      const suffix = text.replace(/[0-9.]/g, '');
      if (!isNaN(num) && !el.dataset.animated) {
        el.dataset.animated = 'true';
        animateCounter(el, num, suffix);
      }
    }
  });
}, { threshold: 0.5 });

document.querySelectorAll('.stat-num, .ov-num, .df-number, .ev-big').forEach(el => {
  statsObserver.observe(el);
});

// ======== PARALLAX HERO ========
window.addEventListener('scroll', () => {
  const hero = document.querySelector('.section-hero');
  if (!hero) return;
  const scrolled = window.scrollY;
  const heroBg = document.querySelector('.hero-video-bg');
  if (heroBg && scrolled < window.innerHeight) {
    heroBg.style.transform = `translateY(${scrolled * 0.3}px)`;
  }
});

// ======== ADD ANIMATION KEYFRAME DYNAMICALLY ========
const style = document.createElement('style');
style.textContent = `
  @keyframes fadeInPanel {
    from { opacity: 0; transform: translateY(16px); }
    to { opacity: 1; transform: translateY(0); }
  }
`;
document.head.appendChild(style);

// ======== HOVER GLOW ON CARDS ========
document.querySelectorAll('.cat-card, .tier-card, .lp-card, .contact-card, .stat-pill').forEach(card => {
  card.addEventListener('mousemove', (e) => {
    const rect = card.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    card.style.setProperty('--gx', x + '%');
    card.style.setProperty('--gy', y + '%');
  });
});

// ======== LOADING SCREEN ========
window.addEventListener('load', () => {
  const loader = document.createElement('div');
  loader.id = 'loader';
  loader.innerHTML = `
    <div class="loader-content">
      <div class="loader-logo">MOA</div>
      <div class="loader-bar"><div class="loader-fill"></div></div>
      <div class="loader-text">MALL OF AMERICA</div>
    </div>
  `;
  
  const loaderStyle = document.createElement('style');
  loaderStyle.textContent = `
    #loader {
      position: fixed; inset: 0; z-index: 9999;
      background: #050505;
      display: flex; align-items: center; justify-content: center;
      transition: opacity 0.6s ease, visibility 0.6s ease;
    }
    #loader.hidden { opacity: 0; visibility: hidden; pointer-events: none; }
    .loader-content { text-align: center; }
    .loader-logo {
      font-family: 'Bebas Neue', sans-serif;
      font-size: 80px; letter-spacing: 12px;
      color: #D4AF37;
      animation: loaderPulse 1s ease infinite alternate;
    }
    @keyframes loaderPulse { from { opacity: 0.4; } to { opacity: 1; } }
    .loader-bar {
      width: 200px; height: 1px;
      background: rgba(212,175,55,0.2);
      margin: 24px auto 16px;
      overflow: hidden;
    }
    .loader-fill {
      height: 100%; width: 0;
      background: #D4AF37;
      animation: loaderBar 1s ease forwards;
    }
    @keyframes loaderBar { to { width: 100%; } }
    .loader-text {
      font-size: 10px; letter-spacing: 6px;
      text-transform: uppercase; color: rgba(250,250,248,0.3);
      font-family: 'DM Sans', sans-serif;
    }
  `;
  document.head.appendChild(loaderStyle);
  document.body.prepend(loader);
  
  setTimeout(() => {
    loader.classList.add('hidden');
    setTimeout(() => loader.remove(), 700);
  }, 1400);
});

console.log('%cMALL OF AMERICA — Interactive Sales Deck', 'color:#D4AF37;font-size:14px;font-weight:bold;font-family:serif;');
console.log('%cBuilt with precision. Designed to convert.', 'color:#888;font-size:11px;');
